#!/bin/bash
cat 0310_Dealer_schedule.txt | grep "$2" | awk -F " " '{print $1,$2,$5,$6}'
