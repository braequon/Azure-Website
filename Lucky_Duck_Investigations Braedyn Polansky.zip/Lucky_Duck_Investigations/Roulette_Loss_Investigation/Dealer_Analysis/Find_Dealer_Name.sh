#!/bin/bash

cat 0310_Dealer_schedule.txt | grep '05:00:00 AM' | awk -F" " '{print $1,$2,$5,$6}'  > Dealers_working_during_losses.txt
cat 0310_Dealer_schedule.txt | grep '08:00:00 AM' | awk -F" " '{print $1,$2,$5,$6}' >> Dealers_working_during_losses.txt
cat 0310_Dealer_schedule.txt | grep '02:00:00 PM' | awk -F" " '{print $1,$2,$5,$6}' >> Dealers_working_during_losses.txt
cat 0310_Dealer_schedule.txt | grep '08:00:00 PM' | awk -F" " '{print $1,$2,$5,$6}' >> Dealers_working_during_losses.txt
cat 0310_Dealer_schedule.txt | grep '11:00:00 PM' | awk -F" " '{print $1,$2,$5,$6}' >> Dealers_working_during_losses.txt
cat 0312_Dealer_schedule.txt | grep '05:00:00 AM' | awk -F" " '{print $1,$2,$5,$6}' >> Dealers_working_during_losses.txt
cat 0312_Dealer_schedule.txt | grep '08:00:00 AM' | awk -F" " '{print $1,$2,$5,$6}' >> Dealers_working_during_losses.txt
cat 0312_Dealer_schedule.txt | grep '02:00:00 PM' | awk -F" " '{print $1,$2,$5,$6}' >> Dealers_working_during_losses.txt
cat 0312_Dealer_schedule.txt | grep '08:00:00 PM' | awk -F" " '{print $1,$2,$5,$6}' >> Dealers_working_during_losses.txt
cat 0312_Dealer_schedule.txt | grep '11:00:00 PM' | awk -F" " '{print $1,$2,$5,$6}' >> Dealers_working_during_losses.txt
cat 0315_Dealer_schedule.txt | grep '05:00:00 AM' | awk -F" " '{print $1,$2,$5,$6}' >> Dealers_working_during_losses.txt
cat 0315_Dealer_schedule.txt | grep '08:00:00 AM' | awk -F" " '{print $1,$2,$5,$6}' >> Dealers_working_during_losses.txt
cat 0315_Dealer_schedule.txt | grep '02:00:00 PM' | awk -F" " '{print $1,$2,$5,$6}' >> Dealers_working_during_losses.txt
